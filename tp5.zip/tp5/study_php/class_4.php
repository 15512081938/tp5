<?php 
// namespace xiaobao\bear\b;
// function gb(){
// 	echo "熊熊";
// }
// class Bear{
// 	public $be = 'bear';
// 	static $name = '喜欢熊';
// 	static $age = '20-30';
// }

// namespace xiaobao\feifei\f;
// function gb(){
// 	echo "狒狒";
// }

// class Bear{
// 	public $be = 'feifei';
// 	static $name = '喜欢飞';
// 	static $age = '20-30';
// }

// use xiaobao\bear\b; //引入空间
// b\gb();
// $g = new b\Bear();
// echo $g -> be;
// echo b\Bear::$name;
// echo b\Bear::$age;
// echo "<br>";
// echo Bear::$name;


namespace xiaobao;
function gb(){
	echo "熊熊";
}
class Bear{
	public $be = 'bear';
	static $name = '喜欢熊';
	static $age = '20-30';
}
const ff = "beibei";
// include("./class_5.php");
// gb();
// echo \ff;
// echo ff;