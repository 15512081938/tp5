<?php 
function gb(){
	echo "feibei";
}
const ff = "肉肉";

include("./class_4.php");
echo ff;
echo "<br>";
echo \ff;
echo "<br>";
echo  \xiaobao\ff;