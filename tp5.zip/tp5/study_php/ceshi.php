<?php

namespace a1\a1;
header("content_type:text/html; charset=utf-8");
function getmsg(){
	echo "a";
}
class An{
	public $obj = 'dog';
	static $name='小宝';
	public $age = '21';
}
const mm="aa";

namespace a2\a2;
function getmsg(){
	echo "b";
}
class An{
	public $obj = 'pig';
	static $name = '小贝';
}
const mm="bb";

getmsg();  //非限定名称访问方式
echo "<br>";
\a1\a1\getmsg();//完全限定名称访问方式
echo "<br>";
echo  mm;//非限定名称访问方式
echo "<br>";
a1\a1\getmsg();

namespace a2\a2\a1\a1;
function getmsg(){
	echo "xiaobei";
}
$a = new \a1\a1\An();
echo "<br>";
echo $a->obj;
echo $a->age;
echo "<br>";
echo \a1\a1\An::$name;
echo \a1\a1\An::$age;