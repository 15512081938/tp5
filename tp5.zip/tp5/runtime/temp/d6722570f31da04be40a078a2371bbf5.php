<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:64:"C:\wamp\www\tp5\public/../application/admin\view\login\login.htm";i:1542987894;}*/ ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml"><!--Head--><head>
    <meta charset="utf-8">
    <title>毕业设计后台登录</title>
    <meta name="description" content="login page">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!--Basic Styles-->
    <link href="http://localhost/tp5/public/static/admin/css/bootstrap.css" rel="stylesheet">
    <link href="http://localhost/tp5/public/static/admin/css/font-awesome.css" rel="stylesheet">
    <!--Beyond styles-->
    <link id="beyond-link" href="http://localhost/tp5/public/static/admin/css/beyond.css" rel="stylesheet">
    <link href="http://localhost/tp5/public/static/admin/css/demo.css" rel="stylesheet">
    <link href="http://localhost/tp5/public/static/admin/css/animate.css" rel="stylesheet">
</head>
<!--Head Ends-->
<!--Body-->

<body>
    <div class="login-container animated fadeInDown">
        <form action="" method="post">
            <div class="loginbox bg-white">
                <div class="loginbox-title">后台登录</div>
                <div class="loginbox-textbox">
                    <input value="admin" class="form-control" placeholder="管理员账号" name="username" type="text">
                </div>
                <div class="loginbox-textbox">
                    <input class="form-control" placeholder="管理员密码" name="password" type="password">
                </div>
                <div class="loginbox-textbox">
                    <input class="form-control" style="width:80px; float:left;" name="code" type="text" placeholder="验证码">
                    <div style="float: left;width: 5px;background:inherit;">&nbsp;&nbsp;</div>
                    <img src="<?php echo captcha_src(); ?>" alt="captcha" 
                   style="float:left;cursor: pointer;"
                   onclick="this.src='<?php echo captcha_src(); ?>?'+ Math.random();" />
                </div>
                <div class="loginbox-textbox"></div>
                <div class="loginbox-textbox"></div>
                <div class="loginbox-submit">
                    <input class="btn btn-primary btn-block" value="登录" type="submit">
                </div>
                <div class="loginbox-submit">
                <a class="btn btn-primary btn-block" href="<?php echo url('Index/index'); ?>">游客登录</a>
                </div>
            </div>
                <div class="logobox">
                    <p style="text-align: center;margin-top: 10px;">版权所有：小宝</p>
                </div>
        </form>
    </div>
    <!--Basic Scripts-->
    <script src="http://localhost/tp5/public/static/admin/js/jquery.js"></script>
    <script src="http://localhost/tp5/public/static/admin/js/bootstrap.js"></script>
    <script src="http://localhost/tp5/public/static/admin/js/jquery_002.js"></script>
    <!--Beyond Scripts-->
    <script src="http://localhost/tp5/public/static/admin/js/beyond.js"></script>




</body><!--Body Ends--></html>