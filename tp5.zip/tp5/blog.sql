-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 2018-12-02 12:08:57
-- 服务器版本： 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog`
--

-- --------------------------------------------------------

--
-- 表的结构 `tp_admin`
--

CREATE TABLE `tp_admin` (
  `id` mediumint(9) NOT NULL,
  `username` varchar(30) NOT NULL COMMENT '管理员名称',
  `password` char(32) NOT NULL COMMENT '管理员密码'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `tp_admin`
--

INSERT INTO `tp_admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '202cb962ac59075b964b07152d234b70'),
(3, '小宝贝', '202cb962ac59075b964b07152d234b70'),
(4, '我猜', '202cb962ac59075b964b07152d234b70'),
(14, 'admind', '202cb962ac59075b964b07152d234b70'),
(9, '宋勇', '202cb962ac59075b964b07152d234b70'),
(10, 'tibei', '202cb962ac59075b964b07152d234b70'),
(11, 'xiaobao', '202cb962ac59075b964b07152d234b70'),
(12, 'babb', '202cb962ac59075b964b07152d234b70');

-- --------------------------------------------------------

--
-- 表的结构 `tp_article`
--

CREATE TABLE `tp_article` (
  `id` mediumint(9) NOT NULL COMMENT '文章id',
  `title` varchar(60) NOT NULL COMMENT '文章标题',
  `author` varchar(30) NOT NULL COMMENT '文章作者',
  `desc` varchar(255) NOT NULL COMMENT '文章简介',
  `keywords` varchar(255) NOT NULL COMMENT '文章关键词',
  `content` text NOT NULL COMMENT '文章内容',
  `pic` varchar(100) NOT NULL COMMENT '缩略图地址',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '点击数',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0：不推荐 1：推荐',
  `time` int(10) NOT NULL COMMENT '发布时间',
  `cateid` mediumint(9) NOT NULL COMMENT '所属栏目'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `tp_article`
--

INSERT INTO `tp_article` (`id`, `title`, `author`, `desc`, `keywords`, `content`, `pic`, `click`, `state`, `time`, `cateid`) VALUES
(1, '金涛', '小宝', '狗子，傻狗', '狗子,傻狗,小肉', '<p style="box-sizing: inherit; -webkit-font-smoothing: antialiased; -webkit-tap-highlight-color: transparent; text-size-adjust: none; line-height: 2; margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(82, 82, 82); font-family: " helvetica="" hiragino="" sans="" microsoft="" wenquanyi="" micro="" font-size:="" white-space:="" background-color:="">如果函数有多个参数需要调用，则使用：</p><pre style="box-sizing: inherit; -webkit-font-smoothing: antialiased; -webkit-tap-highlight-color: transparent; text-size-adjust: none;" andale="" ubuntu="" font-size:="" line-height:="" margin-top:="" margin-bottom:="" padding:="" background-color:="" border:="" 1px="" solid="" border-radius:="" overflow:="" color:="">{$create_time|date=&quot;y-m-d&quot;,###}</pre>', '/uploads/20181122\\13cacaec9d66e01377b6aaa744510f75.jpg', 26, 1, 1542724493, 11),
(3, '小宝', '肉肉', 'http://localhost/tp5/public/index', '肉肉,小贝', '<p>傻狗傻狗傻狗傻狗傻狗傻狗傻狗</p>', '/uploads/20181122\\d0e52e9b4a2f66d14c0e4b1e994d30f7.jpg', 39, 1, 1542725210, 2),
(4, '施宇', '小宝', '肉肉', '肉肉', '<p>小宝</p>', '/uploads/20181122\\a0c5f9d93d0140ddaf17fd7c84c82e2a.jpg', 16, 1, 1542727689, 13),
(5, '体呗', '肉肉', '体呗体呗', '肉肉', '<p>大三大四撒多撒多</p>', '/uploads/20181124\\c2df67ac8ed1c904792cf7ea1fd442cc.jpg', 52, 1, 1542727764, 4),
(6, 'xiaobao', 'xiaobao', '狗子爸爸，傻狗', '狗子爸爸,傻狗', '<p>xiaobao</p>', '/uploads/20181125\\239c59d9f7706bd1fab57bc94998ed0f.jpg', 13, 1, 1542727948, 2),
(7, '傻狗子', '小宝', '哈哈哈', '哈哈哈,傻狗,狗子', '<p>大三大四所大</p>', '/uploads/20181122\\b8a58f156d5e490b0c287ace092b0d05.jpg', 22, 0, 1542728638, 3),
(8, '一只两只', 'saddsa', '一只', '一只,肉肉', '<p>是大大叔大所撒多</p>', '/uploads/20181125\\aade5a4d9c4cdc80bbc000dcd421cb54.jpg', 9, 1, 1542729253, 11),
(9, '家狗', '的萨达', '女装', '傻子,傻狗,女装', '<p>haha&nbsp;</p>', '/uploads/20181121\\a6af71bfacffffa1ffd6ea13a7c56fd1.jpg', 12, 1, 1542729920, 2),
(10, '小菜', 'xiaobao', '体呗在', '可爱,羊肉,一只', '<p>tibei</p>', '/uploads/20181122\\49d0e539e9733bf9e3ccc6ea09e813f1.jpg', 11, 1, 1542880989, 5),
(11, '可爱', '肉肉', '肉肉', '可爱', '<p>小肉</p>', '/uploads/20181122\\17e72f216d6c6c92d4faa71c3f75e2e7.jpg', 29, 0, 1542897712, 2);

-- --------------------------------------------------------

--
-- 表的结构 `tp_cate`
--

CREATE TABLE `tp_cate` (
  `id` mediumint(9) NOT NULL COMMENT '栏目id',
  `catename` varchar(30) NOT NULL COMMENT '栏目名称'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `tp_cate`
--

INSERT INTO `tp_cate` (`id`, `catename`) VALUES
(11, '金涛是条傻狗'),
(2, '小肉'),
(3, '小贝'),
(4, '体呗'),
(5, '羊肉'),
(13, '女装小宇');

-- --------------------------------------------------------

--
-- 表的结构 `tp_links`
--

CREATE TABLE `tp_links` (
  `id` mediumint(9) NOT NULL COMMENT '链接id',
  `title` varchar(30) NOT NULL COMMENT '链接标题',
  `url` varchar(60) NOT NULL COMMENT '链接地址',
  `desc` varchar(255) NOT NULL COMMENT '链接描述'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `tp_links`
--

INSERT INTO `tp_links` (`id`, `title`, `url`, `desc`) VALUES
(1, 'google', 'http://www.google.com', '谷歌网'),
(2, 'Baidu', 'http://www.baidu.com', '百度网'),
(3, 'asdsdasadd', 'http://www.feirou.com', ''),
(4, 'taobao', 'http://www.htaobao.com', '淘宝'),
(9, 'Baidu', 'http://www.baidu.com', ''),
(6, 'addssda', 'http://www.htaddobao.com', ''),
(8, 'yahoo', 'http://www.yahoo.com', ''),
(10, 'sohu', 'http://www.sohu.com', ''),
(11, 'addssda', 'http://www.baid.com', '');

-- --------------------------------------------------------

--
-- 表的结构 `tp_tags`
--

CREATE TABLE `tp_tags` (
  `id` mediumint(9) NOT NULL COMMENT 'tag标签id',
  `tagname` varchar(30) NOT NULL COMMENT 'tag标签名称'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `tp_tags`
--

INSERT INTO `tp_tags` (`id`, `tagname`) VALUES
(1, '第一'),
(4, '第二'),
(3, '小贝'),
(5, '臭肉'),
(6, '黑呗'),
(7, '菜鸡'),
(8, '体呗'),
(10, '小');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tp_admin`
--
ALTER TABLE `tp_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tp_article`
--
ALTER TABLE `tp_article`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tp_cate`
--
ALTER TABLE `tp_cate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tp_links`
--
ALTER TABLE `tp_links`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tp_tags`
--
ALTER TABLE `tp_tags`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `tp_admin`
--
ALTER TABLE `tp_admin`
  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- 使用表AUTO_INCREMENT `tp_article`
--
ALTER TABLE `tp_article`
  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT COMMENT '文章id', AUTO_INCREMENT=12;
--
-- 使用表AUTO_INCREMENT `tp_cate`
--
ALTER TABLE `tp_cate`
  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT COMMENT '栏目id', AUTO_INCREMENT=14;
--
-- 使用表AUTO_INCREMENT `tp_links`
--
ALTER TABLE `tp_links`
  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT COMMENT '链接id', AUTO_INCREMENT=12;
--
-- 使用表AUTO_INCREMENT `tp_tags`
--
ALTER TABLE `tp_tags`
  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT COMMENT 'tag标签id', AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
