document.writeln("<script src=\"http://s9.cnzz.com/stat.php?id=5685897&web_id=5685897\" language=\"JavaScript\"></script>");
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "//hm.baidu.com/hm.js?e2558a635df8de4699c2101b454961e3";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();