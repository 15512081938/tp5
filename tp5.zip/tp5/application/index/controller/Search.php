<?php
namespace app\index\controller;
use app\index\controller\Base;
class Search extends Base
{
    public function index()
    {
    	$keywords=input('keywords');
        if($keywords){
            $if['title']=['like','%'.$keywords.'%'];
            $searchs=db('article')->where($if)->order('id desc')->paginate($listRows=3,$simple=false,$config=['query'=>array('keywords'=>$keywords)]);
            $this->assign(array(
                'searchs'=>$searchs,
                'keywords'=>$keywords,
                ));
        }else{
            $this->assign(array(
                'searchs'=>null,
                'keywords'=>'暂无数据',
                ));
        }
        return $this->fetch('search');
    }
}
