<?php
namespace app\index\controller;
use app\index\controller\Base;
class Article extends Base
{
    public function index()
    {
    	$arrayid=input('arrayid');
    	$articles=db('article')->find($arrayid);
    	$reads=$this->relative($articles['keywords'],$articles['id']);
    	$cates=db('cate')->find($articles['cateid']);
    	$recres=db('article')->where(array('cateid'=>$cates['id'],'state'=>1))->limit(5)->select();
    	$this->assign(array(
    		'articles'=>$articles,
    		'cates'=>$cates,
    		'recres'=>$recres,
    		'reads'=>$reads,
    		));
    	db('article')->where('id','=',$arrayid)->setInc('click'); 
        return $this->fetch('article');
    }

    public function relative($keywords,$id)
    {
    	$arr=explode(',',$keywords);
    	static $reads=array();
    	foreach ($arr as $k=>$v){
    		$if['keywords']=['like','%'.$v.'%'];
    		$if['id']=['neq',$id];
    		$arts=db('article')->where($if)->order('id desc')->limit(8)->select();
    		$reads=array_merge($reads,$arts);
    	}
    	if ($reads) {
    		$reads=arr_unique($reads);
    		return $reads;
    	}
    }
}
