<?php
namespace app\admin\controller;
use think\Controller;
use app\admin\model\Admin;

class Login extends Controller
{
    public function index()
    {
        if(request()->isPost()){       //检测是否为POST请求    
            $data  = input('post.');    //将input输入值传送给data数组
            $admin = new Admin();       //实例化Admin
            $num = $admin->login($data);    //使用Admin的login()方法，并赋给num
            if ($num == 3) {
                $this->success('登录成功！','index/index');
            }elseif ($num == 4) {
               $this->error('验证码错误');
            }
            else{
                $this->error('用户名或者密码错误！');
            }
      }
        return $this->fetch('login');
    }
}


    // if($admin->login($data)==1){
    //     $this->error('用户不存在');
    // }elseif ($admin->login($data)==2) {
    //     $this->error('密码错误');
    // }elseif ($admin->login($data)==3) {
    //     $this->success('登录成功','index/index');
    