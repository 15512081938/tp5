<?php
namespace app\admin\controller;
use app\admin\model\Admin  as AdminModel;
use app\admin\controller\Base;

class Admin extends Base
{
    public function lst(){
    	$list = AdminModel::order('id asc')->paginate(5);		// 把分页数据赋值给模板变量list
		$this->assign('list', $list);
        return $this->fetch();
    }

	public function add()
    {
    	if (request()->isPost()) {
    		$data =[
    		'username'=>input('username'),
    		'password'=>input('password'),
    		]; 
			 $validate = \think\Loader::validate('Admin');
			  // if (!$validate->check($data)) { 			//未引用场景
    		if (!$validate->scene('add')->check($data)) {  		//应用场景scene('add')后
    			$this->error($validate->getError());
    			die;   						//终止程序
    		}
    		if(db('admin')->insert($data)){
    			return $this->success('添加成功管理员！','lst');
    		}else{
    			return $this->error('添加失败管理员！');
    		}
    		return;
    	}
        return $this->fetch();
    }

    public function del(){
    	$id=input('id');
    	if ($id == 1) {
    		$this->error('初始化管理员不能删除！！！');
    	}else{
    		if (db('admin')->delete(input('id'))) {
    			$this->success('成功删除管理员！','lst');
    		}else{
    			$this->error('删除管理员失败！');
    		}		
    	}   	
    }

    public function edit(){
    	$id = input('id');
    	$admins=db('admin')->find($id);
    	if(request()->isPost()){
    	$data=[
    		'id'=>input('id'),
    		'username' =>input('username'),
    		];
    	if(input('password')){
    		$data['password']=md5(input('password'));
    	}else{
    		$data['password']=$admins['password'];
    	}
    	$validate = \think\Loader::validate('Admin');
    	if(!$validate->scene('edit')->check($data)){
    		$this->error($validate->getError()); 	die;
    	}
    	 $save = db('admin')->update($data);
        if($save !== false){
    		$this->success('修改管理员成功！','lst');
    	}else{
    		$this->error('修改管理员失败！');
    	}
    	}
		$this->assign('admins',$admins);
    	return $this->fetch();
    }
    public function logout(){
    	session(null);
    	$this->success('成功退出！','login/index');
    }
}
