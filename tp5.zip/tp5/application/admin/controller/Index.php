<?php
namespace app\admin\controller;
use think\Controller;
// use app\admin\controller\Base;

class Index extends Controller
{
    public function index()
    {
        return $this->fetch();
    }

}
