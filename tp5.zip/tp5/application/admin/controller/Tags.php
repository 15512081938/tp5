<?php
namespace app\admin\controller;
// use app\admin\model\tags as tagsModel;
use app\admin\controller\Base;
class Tags extends Base
{
    public function lst()
    {
    	$list = db('tags')->paginate(5);		// 把分页数据赋值给模板变量list
		$this->assign('list', $list);
        return $this->fetch();
    }


	public function add()
    {
    	if (request()->isPost()) {
    		$data =[
    		'tagname'=>input('tagname'),
    		]; 
			 $validate = \think\Loader::validate('tags');
    		if (!$validate->scene('add')->check($data)) {  		//应用场景scene('add')后
    			$this->error($validate->getError());
    			die;   						//终止程序
    		}
    		if(db('tags')->insert($data)){
    			return $this->success('添加成功Tag标签！','lst');
    		}else{
    			return $this->error('添加失败Tag标签！');
    		}
    		return;
    	}
        return $this->fetch();
    }

    public function del(){
    	$id=input('id');
		if (db('tags')->delete($id)) {
			$this->success('成功删除Tag标签！','lst');
		}else{
			$this->error('删除Tag标签失败！');
		}		
    	  	
    }

    public function edit(){
    	$id = input('id');
    	$tags=db('tags')->find($id);
    	if(request()->isPost()){
    	$data=[
    		'id'=>input('id'),
    		'tagname' =>input('tagname'),
    		];
    	$validate = \think\Loader::validate('tags');
    	if(!$validate->scene('edit')->check($data)){
    		$this->error($validate->getError()); 	die;
    	}
    	 $save = db('tags')->update($data);
        if($save !== false){
    		$this->success('修改Tag标签成功！','lst');
    	}else{
    		$this->error('修改Tag标签失败！');
    	}
    	}
		$this->assign('tags',$tags);
    	return $this->fetch();
    }
}
