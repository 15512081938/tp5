<?php
namespace app\admin\controller;
// use think\Controller;
use app\admin\model\Cate  as CateModel;
use app\admin\controller\Base;
class Cate extends Base
{
    public function lst()
    {
    	$list = CateModel::order('id asc')->paginate(5);		// 把分页数据赋值给模板变量list
		$this->assign('list', $list);
        return $this->fetch();
    }


	public function add()
    {
    	if (request()->isPost()) {
    		$data =[
    		'catename'=>input('catename'),
    		]; 
			 $validate = \think\Loader::validate('Cate');
			  // if (!$validate->check($data)) { 			//未引用场景
    		if (!$validate->scene('add')->check($data)) {  		//应用场景scene('add')后
    			$this->error($validate->getError());
    			die;   						//终止程序
    		}
    		if(db('cate')->insert($data)){
    			return $this->success('添加成功栏目！','lst');
    		}else{
    			return $this->error('添加失败栏目！');
    		}
    		return;
    	}
        return $this->fetch(); 
    }

    public function del(){
    	$id=input('id');
    	if (db('cate')->delete($id)) {
    		$this->success('成功删除栏目！','lst');
    	}else{
    		$this->error('删除栏目失败！');
    	}		 	
    }

    public function edit(){
    	$id = input('id');
    	$cate=db('cate')->find($id);
    	if(request()->isPost()){
    	$data=[
    		'id'=>input('id'),
    		'catename' =>input('catename'),
    		];
    	
    	$validate = \think\Loader::validate('Cate');
    	if(!$validate->scene('edit')->check($data)){
    		$this->error($validate->getError()); 	die;
    	}
        $save = db('cate')->update($data);
    	if($save !== false){
    		$this->success('修改栏目成功！','lst');
    	}else{
    		$this->error('修改栏目失败！');
    	}
    	}
		$this->assign('cate',$cate);
    	return $this->fetch();
    }
}
