<?php
namespace app\admin\controller;
//use think\Controller;
use app\admin\model\Links as LinksModel;
use app\admin\controller\Base;
class Links extends Base
{
    public function lst()
    {
    	$list = LinksModel::paginate(5);		// 把分页数据赋值给模板变量list
		$this->assign('list', $list);
        return $this->fetch();
    }


	public function add()
    {
    	if (request()->isPost()) {
    		$data =[
    		'title'=>input('title'),
    		'url'=>input('url'),
            'desc'=>input('desc'),
    		]; 
			 $validate = \think\Loader::validate('links');
			  // if (!$validate->check($data)) { 			//未引用场景
    		if (!$validate->scene('add')->check($data)) {  		//应用场景scene('add')后
    			$this->error($validate->getError());
    			die;   						//终止程序
    		}
    		if(db('links')->insert($data)){
    			return $this->success('添加成功链接！','lst');
    		}else{
    			return $this->error('添加失败链接！');
    		}
    		return;
    	}
        return $this->fetch();
    }

    public function del(){
    	$id=input('id');
		if (db('links')->delete($id)) {
			$this->success('成功删除链接！','lst');
		}else{
			$this->error('删除链接失败！');
		}		
    	  	
    }

    public function edit(){
    	$id = input('id');
    	$links=db('links')->find($id);
    	if(request()->isPost()){
    	$data=[
    		'id'=>input('id'),
    		'title' =>input('title'),
            'url' =>input('url'),           
            'desc' =>input('desc'),
    		];
    	$validate = \think\Loader::validate('links');
    	if(!$validate->scene('edit')->check($data)){
    		$this->error($validate->getError()); 	die;
    	}
    	 $save = db('links')->update($data);
        if($save !== false){
    		$this->success('修改链接成功！','lst');
    	}else{
    		$this->error('修改链接失败！');
    	}
    	}
		$this->assign('links',$links);
    	return $this->fetch();
    }
}
