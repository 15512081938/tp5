<?php
namespace app\admin\controller;
use think\Controller;               //共用路径控制器Controller
class Base extends Controller
{
    public function _initialize(){          //初始化后台页面
        if (!session('username')) { //如果不存在缓存username
            $this->error('请先登录系统','Login/index');
        }
    }
}
