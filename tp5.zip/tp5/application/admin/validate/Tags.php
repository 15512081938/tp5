<?php
namespace app\admin\validate;
use think\Validate;

class Tags extends Validate
{
    protected  $rule = [
    'tagname' => 'require|unique:tags',
    ];

    protected   $message = [
    'tagname.require' =>'Tag标签名称必须填写',          //输入法中英文
    'tagname.unique' => 'Tag标签不得重复',
    ];

    protected  $scene = [
    'add' =>['tagname'],
    'edit' =>['tagname'],
    ];
}
