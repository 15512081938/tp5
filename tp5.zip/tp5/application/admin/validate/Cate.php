<?php
namespace app\admin\validate;
use think\Validate;

class Cate extends Validate
{
    protected  $rule = [
    'catename' => 'require|min:2|unique:cate',
    ];

    protected   $message = [
    'catename.require' =>'栏目名称必须填写',          //输入法中英文
    'catename.min' => '栏目名称长度不得小于2位',
    'catename.max' => '栏目名称长度不得大于20位',
    'catename.unique' => '栏目名称已存在',
    ]; 

    protected  $scene = [
    'add' =>['catename'=> 'require|max:20|min:2|unique:cate'],
    'edit' =>['catename'=> 'require|max:20|min:2|unique:cate'],
    ];
}
