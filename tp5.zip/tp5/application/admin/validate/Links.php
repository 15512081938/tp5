<?php
namespace app\admin\validate;
use think\Validate;

class Links extends Validate
{
    protected  $rule = [
    'title' => 'require|min:2',
  	'url'   => 'url',
    ];

    protected   $message = [
    'title.require' =>'链接名称必须填写',          //输入法中英文
    'title.min' => '链接名称长度不得小于2位',
    'title.max' => '链接名称长度不得大于20位',
    'url' => '链接地址不符合规则',
    ];

    protected  $scene = [
    'add' =>['title','url'],
    'edit' =>['title','url'],
    ];
}
