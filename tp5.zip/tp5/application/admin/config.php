<?php

return [

    // 视图输出字符串内容替换
    'view_replace_str'       => [
    '__PUBLIC__'             => SITE_URL.'/public/static/admin',
    '__IMG__'         	     => SITE_URL.'/public/static',
    ],

	//模板后綴
    'template'   			=> [
	'view_suffix'			=> 'htm',
    ],
];
  