<?php
namespace app\admin\model;
use think\Model;
use think\Db;
use \think\captcha\Captcha;  
class Admin extends Model
{
 	public function login($data){  
 		$captcha = new Captcha();
 		if (!$captcha->check($data['code'])) {
 			return 4; 								 //数据模型不能返回$this
 		}
 		$user = Db::name('admin')->where('username','=',$data['username'])->find();
 		if($user){
 			if($user['password'] == md5($data['password'])){
 				session('userid',$user['id']);
 				session('username',$user['username']);
 				return 3;							//信息正确
 			}else{
 				return 1;							 //密码错误
 			}
 		}else{
 			return 1;								//用户名不存在
 		}
 	}
 }
